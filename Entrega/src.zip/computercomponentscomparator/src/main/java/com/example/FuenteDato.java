package com.example;

public interface FuenteDato {
	
	public String query(String request);
}
